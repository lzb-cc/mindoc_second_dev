#### URL
```http
http://s.fts.yy.com/subscribe/unsubscribe_compere   #GET
```

#### 请求参数
参数| 类型| 默认值| 描述|
:-:| :-:| :-:| :-:
uid| int64| NOT NULL| 用户UID，cookie
compere_uid| int64| NULL| 主持UID
callback| string| helloworld| 回调参数

#### 返回参数
参数| 类型|  描述|
:-:| :-:| :-:| :-:
status| int| 0 成功，-1 失败，-2 cookie验证失败， -3参数错误

#### 请求示例
>[http://s.fts.yy.com/subscribe/unsubscribe_compere?compere_uid=9527&callback=helloworld]http://s.fts.yy.com/subscribe/unsubscribe_compere?compere_uid=9527&callback=helloworld)

#### 返回示例
```json
helloworld({
	"status": 0
})
```